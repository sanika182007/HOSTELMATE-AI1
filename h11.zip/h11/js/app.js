const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const STORAGE_KEY = "hostelmate-ai-demo-v1";
const SESSION_KEY = "hostelmate-ai-session";
const PAGE_ROLE = document.body.dataset.role || "student";
const LOGIN_PAGES = { student: "student-login.html", warden: "warden-login.html" };
const session = (() => { try { return JSON.parse(sessionStorage.getItem(SESSION_KEY)); } catch { return null; } })();
// Not logged in (or logged in as the other role in this tab) -> send to this role's login page
if (!session || session.role !== PAGE_ROLE) { document.documentElement.style.display = "none"; location.replace(LOGIN_PAGES[PAGE_ROLE]); }
const today = new Date();
const fmtDate = (date=today) => date.toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"});
const safeId = () => "HM" + Math.random().toString(36).slice(2,7).toUpperCase();
const starterData = () => ({
  complaints:[
    {id:"HM1042",title:"Wi-Fi not working in Block B",description:"Wi-Fi keeps disconnecting since morning in Block B.",category:"Wi-Fi",priority:"High",status:"In progress",room:"Block B",created:fmtDate(),student:"Aarav S."},
    {id:"HM1041",title:"Water tap leaking",description:"The bathroom tap is leaking in room 203.",category:"Water",priority:"Medium",status:"Pending",room:"Room 203",created:fmtDate(),student:"Chiranthan L"}
  ],
  leaves:[
    {id:"LV204",type:"Day leave",from:isoToday(),to:isoToday(),reason:"Visit family",status:"Pending",student:"Chiranthan L",created:fmtDate()},
    {id:"LV203",type:"Weekend leave",from:isoOffset(3),to:isoOffset(4),reason:"Going home for the weekend",status:"Approved",student:"Aarav S.",created:fmtDate()}
  ],
  announcements:[
    {id:"AN01",title:"Water supply maintenance",body:"Water supply in Block B may be interrupted tomorrow from 10 AM to 12 PM. Please plan ahead.",date:fmtDate(),tag:"Maintenance"},
    {id:"AN02",title:"Mess menu update",body:"The updated weekly menu is now available. Share your feedback after meals so the mess team can keep improving.",date:fmtDate(),tag:"Mess"},
    {id:"AN03",title:"Hostel community evening",body:"Join us in the common room on Friday at 6 PM for games, music and snacks. Everyone is welcome!",date:fmtDate(),tag:"Event"}
  ],
  feedback:[],
  lostFound:[
    {id:"LF1001",title:"Blue water bottle",category:"Bottle",kind:"Lost",location:"Library, 1st floor",description:"Blue steel bottle with a small sticker.",contact:"Hostel reception",student:"Aarav S.",date:fmtDate(),status:"Open"},
    {id:"LF1002",title:"Black wireless earbuds case",category:"Electronics",kind:"Found",location:"Cafeteria entrance",description:"Black charging case found near the entrance.",contact:"Hostel reception",student:"Priya M.",date:fmtDate(),status:"Open"}
  ],
  bookings:[
    {id:"BK101",facility:"Laundry",date:isoToday(),slot:"6:00 PM",student:"Aarav S.",status:"Confirmed",created:fmtDate()}
  ],
  menu:{
    Monday:{Breakfast:{emoji:"🥞",items:"Idli, sambar & chutney"},Lunch:{emoji:"🍛",items:"Rice, sambar, potato curry & curd"},Dinner:{emoji:"🥗",items:"Chapati, dal & vegetable"}},
    Tuesday:{Breakfast:{emoji:"🍳",items:"Dosa, chutney & sambar"},Lunch:{emoji:"🍚",items:"Rice, rasam, beans palya & curd"},Dinner:{emoji:"🫓",items:"Chapati, paneer curry & salad"}},
    Wednesday:{Breakfast:{emoji:"🥣",items:"Pongal, chutney & coffee"},Lunch:{emoji:"🍲",items:"Veg pulao, raita & papad"},Dinner:{emoji:"🍜",items:"Noodles, manchurian & soup"}},
    Thursday:{Breakfast:{emoji:"🍞",items:"Bread, omelette & fruit"},Lunch:{emoji:"🥘",items:"Rice, sambar, mixed veg & curd"},Dinner:{emoji:"🫓",items:"Roti, chana masala & salad"}},
    Friday:{Breakfast:{emoji:"🧇",items:"Poori, saagu & chutney"},Lunch:{emoji:"🍱",items:"Rice, dal, veg curry & curd"},Dinner:{emoji:"🍝",items:"Pasta, garlic bread & soup"}},
    Saturday:{Breakfast:{emoji:"🥪",items:"Sandwich, banana & milk"},Lunch:{emoji:"🍛",items:"Veg biryani, raita & salan"},Dinner:{emoji:"🥞",items:"Dosa, chutney & sambar"}},
    Sunday:{Breakfast:{emoji:"🍩",items:"Poori, saagu & sweet"},Lunch:{emoji:"🍚",items:"Special meal, rice, curry & dessert"},Dinner:{emoji:"🥣",items:"Khichdi, curd & pickle"}}
  },
  students:["Chiranthan L","Aarav S.","Priya M.","Rohan K.","Ananya R.","Kabir P."]
});
function isoToday(){return isoOffset(0)}
function isoOffset(days){const d=new Date();d.setDate(d.getDate()+days);return d.toLocaleDateString("en-CA")}
function loadData(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY))||starterData()}catch{return starterData()}}
let data=loadData(), role=PAGE_ROLE, userName=(session&&session.name)||(PAGE_ROLE==="warden"?"Warden":"Student"), currentView="dashboard", selectedDay=today.toLocaleDateString("en-US",{weekday:"long"}), selectedRating=0, lastAnalysis=null;
if(!data.menu) data=starterData();
if(!Array.isArray(data.lostFound)) data.lostFound=starterData().lostFound;
data.lostFound.forEach(lfNorm);
if(!Array.isArray(data.bookings)) data.bookings=starterData().bookings;
function save(){try{const cur=JSON.parse(localStorage.getItem(STORAGE_KEY)||"null");if(cur&&Array.isArray(cur.lostFound)){data.lostFound=cur.lostFound;data.lostFound.forEach(lfNorm)}}catch{}const raw=JSON.stringify(data);localStorage.setItem(STORAGE_KEY,raw);lastRaw=raw;try{lfChannel&&lfChannel.postMessage({t:Date.now()})}catch{}}
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove("show"),2800)}
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function statusClass(s){return String(s).toLowerCase().replace(/\s+/g,"-")}
function statusPill(s){return `<span class="status ${statusClass(s)}">${esc(s)}</span>`}
function iconForCategory(c){return ({Water:"💧",Electricity:"⚡","Wi-Fi":"⌁",Maintenance:"🛠️","Mess/Food":"♨",Security:"🛡️",Other:"✦"})[c]||"✦"}
function analyzeComplaint(text){
 const t=text.toLowerCase();
 const rules=[
  {category:"Water",words:["water","tap","leak","pipe","shower","drinking","plumbing"]},
  {category:"Electricity",words:["electric","power","light","fan","switch","socket","charging","current"]},
  {category:"Wi-Fi",words:["wi-fi","wifi","internet","network","router","connectivity","signal"]},
  {category:"Maintenance",words:["repair","broken","door","window","bed","furniture","room","clean","plumbing","pest","leak"]},
  {category:"Mess/Food",words:["food","mess","meal","breakfast","lunch","dinner","taste","menu","hungry"]},
  {category:"Security",words:["security","unsafe","lock","theft","gate","stranger","harass"]}
 ];
 let category="Other", max=0;
 rules.forEach(r=>{const count=r.words.reduce((n,w)=>n+(t.includes(w)?1:0),0);if(count>max){max=count;category=r.category}});
 let priority="Low";
 if(/urgent|emergency|danger|sparking|smoke|fire|no water|not working|can't|cannot|leaking|unsafe|theft|broken/i.test(text))priority="High";
 else if(/issue|problem|repair|slow|dirty|noise|not enough|stopped/i.test(text))priority="Medium";
 let suggestion=({
  Water:"Check the affected tap/line and assign the maintenance team.",
  Electricity:"Ask an electrician to inspect the fixture safely.",
  "Wi-Fi":"Check router status and connectivity in the affected block.",
  Maintenance:"Create a maintenance task and inspect the reported area.",
  "Mess/Food":"Share feedback with the mess supervisor and review meal trends.",
  Security:"Escalate to the warden/security team for prompt review.",
  Other:"Review the details and route this to the appropriate hostel team."
 })[category];
 return {category,priority,suggestion,confidence:max?Math.min(98,76+max*6):54};
}
function setRole(next,name=userName){role=next;userName=name||"Student";$("#roleName").textContent=userName;$("#roleLabel").textContent=role==="warden"?"Warden / Admin account":"Student account";$("#roleAvatar").textContent=role==="warden"?"🧑🏻‍💼":"👩🏻‍🎓";$("#topAvatar").textContent=role==="warden"?"🧑🏻‍💼":"👩🏻‍🎓";$("#topUserName").textContent=userName.split(" ")[0];$$(".admin-only").forEach(el=>el.classList.toggle("hidden",role!=="warden"));renderView()}
function closeModal(){ lostState.openId=null; $$(".modal-backdrop").forEach(m=>m.classList.add("hidden"))}
function logout(){sessionStorage.removeItem(SESSION_KEY);location.href=LOGIN_PAGES[PAGE_ROLE]}
function goView(view){currentView=view;$$(".nav-item[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===view));$("#pageTitle").textContent=({dashboard:"Dashboard",complaints:"Complaints",mess:"Mess menu & feedback",leave:"Leave requests",announcements:"Announcements",lostfound:"Lost & Found",booking:"Facility booking",students:"Students"})[view]||"Dashboard";$("#sideNav").closest(".sidebar").classList.remove("open");const overlay=$(".mobile-overlay");if(overlay)overlay.classList.remove("show");renderView()}
function heading(title,desc,action=""){return `<div class="page-heading"><div><h1>${title}</h1><p>${desc}</p></div><div class="heading-actions">${action}</div></div>`}
function stat(icon,color,label,value,foot){return `<div class="stat-card"><div class="stat-top"><span class="stat-label">${label}</span><span class="stat-icon ${color}">${icon}</span></div><h3>${value}</h3><div class="stat-foot">${foot}</div></div>`}
function complaintRows(items){if(!items.length)return `<div class="empty-state"><span>✦</span><b>All clear for now</b><p>No complaints match this view.</p></div>`;return items.map(c=>`<div class="complaint-row"><span class="row-symbol">${iconForCategory(c.category)}</span><div class="row-content"><b>${esc(c.title)}</b><small>${esc(c.id)} · ${esc(c.room||"Hostel")} · ${esc(c.created)}</small></div>${statusPill(c.status)}</div>`).join("")}
function miniMenu(day=selectedDay){const m=data.menu[day]||data.menu.Monday;return `<div class="menu-today">${["Breakfast","Lunch","Dinner"].map((meal,i)=>`<div class="meal-card"><div class="meal-art">${m[meal].emoji}</div><div class="meal-info"><b>${meal}</b><small>${esc(m[meal].items)}</small></div></div>`).join("")}</div>`}
function dashboardView(){
 const mine=data.complaints.filter(c=>role==="warden"||c.student===userName), myLeaves=data.leaves.filter(l=>role==="warden"||l.student===userName);
 const pending=data.complaints.filter(c=>c.status==="Pending"||c.status==="In progress").length;
 const stats=role==="warden"?[stat("⌁","purple","Total complaints",data.complaints.length,`<span class="positive">${pending} need attention</span>`),stat("↗","mint","Leave requests",data.leaves.length,`${data.leaves.filter(l=>l.status==="Pending").length} awaiting review`),stat("♧","blue","Students",data.students.length,"Registered demo profiles"),stat("✳","peach","Announcements",data.announcements.length,"Visible to hostel residents")]:[stat("⌁","purple","My complaints",mine.length,`${mine.filter(c=>c.status!=="Resolved").length} still active`),stat("↗","mint","Leave requests",myLeaves.length,`${myLeaves.filter(l=>l.status==="Pending").length} awaiting review`),stat("♨","peach","Today's mess","3 meals","Breakfast · Lunch · Dinner"),stat("✳","blue","Announcements",data.announcements.length,"Latest hostel updates")];
 return `${heading(role==="warden"?"Welcome back, Warden! 👋":`Hey, ${esc(userName.split(" ")[0])}! 👋`,"Here's what's happening around your hostel today.",role==="warden"?`<button class="btn btn-primary btn-sm" data-action="new-announcement">＋ New announcement</button>`:`<button class="btn btn-primary btn-sm" data-view="complaints">＋ Submit complaint</button>`)}
 <div class="stats-grid">${stats.join("")}</div>
 <div class="dashboard-grid"><section class="panel"><div class="panel-header"><div><h3>${role==="warden"?"Recent complaints":"Your recent complaints"}</h3><p>Every issue deserves a follow-up.</p></div><button class="panel-link" data-view="complaints">View all →</button></div><div class="complaint-list">${complaintRows([...mine].reverse().slice(0,4))}</div>${role==="warden"?`<div class="ai-insight"><span class="ai-star">✦</span><div><b>AI complaint snapshot</b><p>${pending?`${pending} issue(s) are still open. Review high-priority requests first.`:"Everything is marked resolved. Great work!"}</p></div></div>`:""}</section>
 <section class="panel"><div class="panel-header"><div><h3>Today's mess menu</h3><p>A little preview of what's cooking.</p></div><button class="panel-link" data-view="mess">Full menu →</button></div>${miniMenu()}</section></div>
 <section class="panel"><div class="panel-header"><div><h3>Quick actions</h3><p>Get the little things done in a few clicks.</p></div></div><div class="quick-actions">${role==="warden"?`<button class="quick-action" data-view="complaints"><span>⌁</span><b>Review complaints</b><small>${pending} still open</small></button><button class="quick-action" data-view="leave"><span>↗</span><b>Review leave</b><small>${data.leaves.filter(l=>l.status==="Pending").length} awaiting a decision</small></button><button class="quick-action" data-action="new-announcement"><span>✳</span><b>Post announcement</b><small>Tell residents what's new</small></button>`:`<button class="quick-action" data-view="complaints"><span>⌁</span><b>Report an issue</b><small>Let us know what needs fixing</small></button><button class="quick-action" data-view="leave"><span>↗</span><b>Request leave</b><small>Submit and track your plans</small></button><button class="quick-action" data-view="mess"><span>♨</span><b>Rate your meal</b><small>Your feedback matters</small></button>`}</div></section>
 <section class="panel" style="margin-top:16px"><div class="panel-header"><div><h3>Latest announcements</h3><p>Don't miss a hostel update.</p></div><button class="panel-link" data-view="announcements">View all →</button></div>${announcementCards(data.announcements.slice(0,2))}</section>`;
}
function complaintsView(){
 if(role==="warden"){const open=data.complaints.filter(c=>c.status!=="Resolved").length,high=data.complaints.filter(c=>c.priority==="High"&&c.status!=="Resolved").length;return `${heading("Complaint management","Review every complaint and update its status as work progresses.",`<span class="pill pill-high">${high} high priority</span> <span class="pill pill-pending">${open} open</span>`)}<section class="panel"><div class="panel-header"><div><h3>All complaints</h3><p>Change the status from the dropdown in each row.</p></div><button class="panel-link" id="refreshComplaints">↻ Refresh</button></div><div id="complaintTable">${complaintTable()}</div></section>`}
 return `${heading("Complaint center","Tell us what's wrong. Our built-in AI helper will categorize your issue and suggest a priority.",`<span class="pill pill-high">AI-assisted</span>`)}<div class="dashboard-grid"><section class="form-panel"><div class="panel"><div class="panel-header"><div><h3>Submit a complaint</h3><p>Give us enough detail to get it to the right team.</p></div><span class="stat-icon purple">✦</span></div><form id="complaintForm"><div class="field"><label for="complaintTitle">Short title</label><input id="complaintTitle" required maxlength="90" placeholder="e.g. Wi-Fi not working in Block B"/></div><div class="field"><label for="complaintDescription">Describe the issue</label><textarea id="complaintDescription" required maxlength="700" placeholder="Where is it happening? When did you notice it? Any helpful details..."></textarea><small>Tip: mention words like water, Wi-Fi, electricity or food for more accurate categorization.</small></div><div class="field"><label>Choose a category (optional — AI can suggest one)</label><div class="category-chips" id="categoryChips">${["Water","Electricity","Wi-Fi","Maintenance","Mess/Food","Security","Other"].map(c=>`<button type="button" class="category-chip" data-category="${c}">${iconForCategory(c)} ${c}</button>`).join("")}</div><input type="hidden" id="manualCategory" value=""/></div><div class="ai-result" id="aiResult"></div><div class="form-actions"><button type="button" class="btn btn-outline btn-sm" id="analyzeBtn">✦ Analyze with AI</button><button class="btn btn-primary btn-sm" type="submit">Submit complaint →</button></div></form></div></section><section><div class="panel"><div class="panel-header"><div><h3>How the AI helper works</h3><p>A small assist, not a mystery box.</p></div></div><div class="ai-insight"><span class="ai-star">✦</span><div><b>Text-based categorization</b><p>It looks for common keywords to suggest a category, priority and next action. No external AI service is called.</p></div></div><div class="panel-header" style="margin-top:22px"><h3>Common categories</h3></div>${["Water","Electricity","Wi-Fi","Maintenance","Mess/Food","Security"].map(c=>`<div class="complaint-row" style="margin-bottom:8px"><span class="row-symbol">${iconForCategory(c)}</span><div class="row-content"><b>${c}</b><small>${({Water:"Leaks, taps, water supply",Electricity:"Lights, fans, power issues","Wi-Fi":"Internet, router, connectivity",Maintenance:"Room repairs and cleaning","Mess/Food":"Meal quality or menu",Security:"Locks and safety concerns"})[c]}</small></div></div>`).join("")}</div></section></div><section class="panel" style="margin-top:16px"><div class="panel-header"><div><h3>${role==="warden"?"All complaints":"Your complaint history"}</h3><p>Check status and follow progress.</p></div><button class="panel-link" id="refreshComplaints">↻ Refresh</button></div><div id="complaintTable">${complaintTable()}</div></section>`}
function complaintTable(){let items=data.complaints.filter(c=>role==="warden"||c.student===userName);if(!items.length)return `<div class="empty-state"><span>⌁</span><b>No complaints yet</b><p>Your submitted issues will appear here.</p></div>`;return `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>ISSUE</th><th>CATEGORY</th><th>PRIORITY</th><th>DATE</th><th>STATUS</th>${role==="warden"?"<th>ACTION</th>":""}</tr></thead><tbody>${[...items].reverse().map(c=>`<tr><td><b>${esc(c.title)}</b><span class="table-sub">${esc(c.id)} · ${esc(c.student)}</span></td><td>${iconForCategory(c.category)} ${esc(c.category)}</td><td>${statusPill(c.priority)}</td><td>${esc(c.created)}</td><td>${statusPill(c.status)}</td>${role==="warden"?`<td><select class="tiny-btn" data-complaint-status="${c.id}" aria-label="Update status"><option ${c.status==="Pending"?"selected":""}>Pending</option><option ${c.status==="In progress"?"selected":""}>In progress</option><option ${c.status==="Resolved"?"selected":""}>Resolved</option></select></td>`:""}</tr>`).join("")}</tbody></table></div>`}
function leaveView(){const mine=data.leaves.filter(l=>role==="warden"||l.student===userName);
 if(role==="warden")return `${heading("Leave requests","Review student requests and approve or reject them.",`<span class="pill pill-pending">${data.leaves.filter(l=>l.status==="Pending").length} pending</span>`)}<section class="panel"><div class="panel-header"><div><h3>All leave requests</h3><p>Approve, reject or reset a request.</p></div></div>${leaveTable(mine)}</section>`;
 return `${heading("Leave requests","Plans coming up? Send a request and track the decision here.",role==="warden"?`<span class="pill pill-pending">${data.leaves.filter(l=>l.status==="Pending").length} pending</span>`:"")}<div class="dashboard-grid"><section class="form-panel"><div class="panel"><div class="panel-header"><div><h3>Request leave</h3><p>Fill in the details for your warden.</p></div><span class="stat-icon mint">↗</span></div><form id="leaveForm"><div class="field"><label for="leaveType">Leave type</label><select id="leaveType"><option>Day leave</option><option>Overnight leave</option><option>Weekend leave</option><option>Emergency leave</option></select></div><div class="form-grid"><div class="field"><label for="leaveFrom">From date</label><input type="date" id="leaveFrom" min="${isoToday()}" required value="${isoToday()}"/></div><div class="field"><label for="leaveTo">To date</label><input type="date" id="leaveTo" min="${isoToday()}" required value="${isoToday()}"/></div></div><div class="field"><label for="leaveReason">Reason for leave</label><textarea id="leaveReason" required maxlength="500" placeholder="Briefly tell us why you need leave..."></textarea></div><div class="form-actions"><button class="btn btn-primary btn-sm">Send request →</button></div></form></div></section><section class="panel"><div class="panel-header"><div><h3>Before you go</h3><p>A few helpful reminders.</p></div></div>${[["✓","Submit early","Give your warden time to review the request."],["✦","Be clear","Add the dates and a short reason."],["↗","Check your status","Approval is shown in your request history."]].map(([i,t,p])=>`<div class="complaint-row" style="margin-bottom:10px"><span class="row-symbol">${i}</span><div class="row-content"><b>${t}</b><small>${p}</small></div></div>`).join("")}</section></div><section class="panel" style="margin-top:16px"><div class="panel-header"><div><h3>${role==="warden"?"All leave requests":"My leave history"}</h3><p>${role==="warden"?"Review requests and update their status.":"Your leave requests and their latest status."}</p></div></div>${leaveTable(mine)}</section>`}
function leaveTable(items){if(!items.length)return `<div class="empty-state"><span>↗</span><b>No leave requests yet</b><p>Your requests will show up here.</p></div>`;return `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>REQUEST</th><th>LEAVE TYPE</th><th>DATES</th><th>REASON</th><th>STATUS</th>${role==="warden"?"<th>ACTION</th>":""}</tr></thead><tbody>${[...items].reverse().map(l=>`<tr><td><b>${esc(l.id)}</b><span class="table-sub">${esc(l.student)}</span></td><td>${esc(l.type)}</td><td>${esc(l.from)}<span class="table-sub">to ${esc(l.to)}</span></td><td>${esc(l.reason)}</td><td>${statusPill(l.status)}</td>${role==="warden"?`<td><div class="table-actions">${l.status==="Pending"?`<button class="tiny-btn approve" data-leave-action="Approved" data-id="${l.id}">Approve</button><button class="tiny-btn reject" data-leave-action="Rejected" data-id="${l.id}">Reject</button>`:`<button class="tiny-btn" data-leave-action="Pending" data-id="${l.id}">Reset</button>`}</div></td>`:""}</tr>`).join("")}</tbody></table></div>`}
function messView(){const m=data.menu[selectedDay]||data.menu.Monday;const ratings=data.feedback;const avg=ratings.length?(ratings.reduce((n,r)=>n+r.rating,0)/ratings.length).toFixed(1):"—";const count=ratings.length;return `${heading("Mess menu & feedback","See what's on the menu and help make the next meal even better.")}<div class="mess-layout"><section class="panel"><div class="panel-header"><div><h3>This week's menu</h3><p>Menus are demo examples and can be edited in the JavaScript data.</p></div><span class="stat-icon peach">♨</span></div><div class="day-tabs">${Object.keys(data.menu).map(d=>`<button class="day-tab ${selectedDay===d?"active":""}" data-day="${d}">${d.slice(0,3)}</button>`).join("")}</div>${["Breakfast","Lunch","Dinner"].map(meal=>`<div class="mess-meal"><span class="mess-emoji">${m[meal].emoji}</span><div><b>${meal}</b><p>${esc(m[meal].items)}</p><small>${meal==="Breakfast"?"7:30–9:00 AM":meal==="Lunch"?"12:30–2:00 PM":"7:30–9:00 PM"}</small></div><span class="pill" style="background:#effbf5;color:#219c74">On menu</span></div>`).join("")}</section><aside>${role==="warden"?"":`<section class="panel"><div class="panel-header"><div><h3>Rate today's meals</h3><p>Your feedback helps improve the menu.</p></div></div><form id="feedbackForm"><div class="field"><label for="feedbackMeal">Meal</label><select id="feedbackMeal"><option>Breakfast</option><option>Lunch</option><option>Dinner</option></select></div><div class="field"><label>Your rating</label><div class="rating-stars" id="ratingStars">${[1,2,3,4,5].map(n=>`<button type="button" data-rating="${n}" aria-label="${n} stars">★</button>`).join("")}</div><small id="ratingHelp">Tap a star to rate</small></div><div class="field"><label for="feedbackText">Anything to share? (optional)</label><textarea id="feedbackText" maxlength="300" placeholder="What did you enjoy? What could be better?" style="min-height:80px"></textarea></div><button class="btn btn-primary btn-sm" style="width:100%">Send feedback →</button></form></section>`}<section class="panel" style="margin-top:${role==="warden"?0:14}px"><div class="panel-header"><div><h3>Feedback snapshot</h3><p>${role==="warden"?"What students are saying about the mess.":"Based on feedback in this browser."}</p></div><span class="stat-icon mint">✦</span></div><div class="feedback-stat"><b>${avg}</b><span>average rating · ${count} response${count===1?"":"s"}</span></div>${[5,4,3,2,1].map(n=>{const c=ratings.filter(r=>r.rating===n).length;return `<div class="bar-row"><span>${n} stars</span><div class="bar-track"><div class="bar-fill" style="width:${count?c/count*100:0}%"></div></div><span>${c}</span></div>`}).join("")}<div class="ai-insight"><span class="ai-star">✦</span><div><b>AI food insight</b><p>${foodInsight()}</p></div></div></section></aside></div>`}
function foodInsight(){if(!data.feedback.length)return "No feedback yet. Once students rate meals, this area summarizes the emerging preferences.";const words=data.feedback.map(f=>f.text.toLowerCase()).join(" ");const likes=[];if(/spicy|spice|masala/.test(words))likes.push("flavourful meals");if(/healthy|salad|fruit|vegetable/.test(words))likes.push("healthier options");if(/variety|different|repeat|same/.test(words))likes.push("more menu variety");if(/sweet|dessert|payasam/.test(words))likes.push("occasional desserts");if(/less oil|oily|greasy/.test(words))likes.push("lighter, less-oily food");const avg=data.feedback.reduce((a,f)=>a+f.rating,0)/data.feedback.length;return `${avg>=4?"Overall feedback is positive":avg>=3?"Feedback is mixed":"Recent ratings suggest room to improve"}. ${likes.length?"Common themes mention "+likes.join(", ")+".":"More written feedback will help identify specific preferences."} This is a simple keyword summary, not a trained AI model.`}
function announcementCards(items){if(!items.length)return `<div class="empty-state"><span>✳</span><b>No announcements yet</b><p>New hostel updates will appear here.</p></div>`;return items.map(a=>`<div class="announcement-card"><span class="announcement-icon">${a.tag==="Maintenance"?"⚙":a.tag==="Mess"?"♨":a.tag==="Event"?"✦":"✳"}</span><div style="flex:1"><h4>${esc(a.title)}</h4><p>${esc(a.body)}</p><small>${esc(a.date)} · ${esc(a.tag)}</small></div>${role==="warden"?`<button class="tiny-btn reject" data-delete-announcement="${a.id}">Delete</button>`:""}</div>`).join("")}
function announcementsView(){return `${heading("Announcements","The latest updates from your hostel team.",role==="warden"?`<button class="btn btn-primary btn-sm" data-action="new-announcement">＋ New announcement</button>`:"")}<section class="panel"><div class="panel-header"><div><h3>Hostel noticeboard</h3><p>Stay up to date with events, maintenance and mess changes.</p></div><span class="pill">${data.announcements.length} updates</span></div>${announcementCards([...data.announcements].reverse())}</section>`}
/* =====================================================================
   LOST & FOUND — claims workflow, smart matches, photos and live sync
   between windows. Every write goes through lfUpdate(), which re-reads the
   latest saved data first, so two open windows never overwrite each other.
   ===================================================================== */
const LF_CATEGORIES=["Electronics","Bottle","Clothing","Keys","Books","Other"];
const LF_ICONS={Bottle:"◉",Electronics:"⌁",Clothing:"◇",Keys:"⚿",Books:"▤",Other:"✦"};
const LF_ROUTES=["Hostel reception","Warden office","Security desk"];
const LF_PLACES=["Library","Mess hall","Common room","Block A lobby","Block B lobby","Laundry area","Gym","Sports ground","Reception","Study room"];
const LF_UI_KEY="hostelmate-ai-lf-ui";
const LF_ACTIVE=["Open","Claim pending"];
// Filters are remembered per window (sessionStorage), so each window keeps its own view
const lostState=Object.assign({q:"",kind:"All",status:"All",category:"All",sort:"new",mine:false},(()=>{try{return JSON.parse(sessionStorage.getItem(LF_UI_KEY))||{}}catch{return {}}})(),{openId:null});
let lastRaw=localStorage.getItem(STORAGE_KEY);
let lfLastSync=new Date();
const lfChannel=("BroadcastChannel" in window)?new BroadcastChannel("hostelmate-ai-sync"):null;

function lfSaveUi(){try{const s={...lostState};delete s.openId;sessionStorage.setItem(LF_UI_KEY,JSON.stringify(s))}catch{}}
function lfNorm(x){if(!Array.isArray(x.claims))x.claims=[];if(!Array.isArray(x.history))x.history=[];if(x.status==="Resolved")x.status="Returned";if(!x.status)x.status="Open";return x}
function lfRecalc(x){if(LF_ACTIVE.includes(x.status))x.status=x.claims.some(c=>c.status==="Pending")?"Claim pending":"Open"}
function lfLog(x,text){x.history.push({at:new Date().toISOString(),text});if(x.history.length>30)x.history.shift()}
function lfWhen(iso){const d=new Date(iso);if(isNaN(d))return"";const s=(Date.now()-d)/1000;if(s<45)return"just now";if(s<3600)return Math.round(s/60)+" min ago";return d.toLocaleString("en-IN",{day:"numeric",month:"short",hour:"numeric",minute:"2-digit"})}
function lfDateLabel(x){if(x.eventDate){const d=new Date(x.eventDate+"T00:00:00");if(!isNaN(d))return d.toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"})}return x.date||""}
function lfSafePhoto(p){return/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(p||"")?p:""}
function lfNewId(items){let id;do{id="LF"+Math.random().toString(36).slice(2,6).toUpperCase()}while(items.some(i=>i.id===id));return id}
function lfStatusPill(s){return`<span class="lf-status ${statusClass(s)}">${esc(s)}</span>`}
function lfCurrentData(){const d=loadData();if(!Array.isArray(d.lostFound))d.lostFound=starterData().lostFound;if(!Array.isArray(d.bookings))d.bookings=starterData().bookings;d.lostFound.forEach(lfNorm);return d}

// Read-modify-write on the freshest saved data. Return false from fn to cancel.
function lfUpdate(fn){
  const fresh=lfCurrentData();
  if(fn(fresh.lostFound)===false)return false;
  const raw=JSON.stringify(fresh);
  try{localStorage.setItem(STORAGE_KEY,raw)}catch{toast("Browser storage is full — try a smaller photo or archive old listings.");return false}
  lastRaw=raw;data=fresh;
  try{lfChannel&&lfChannel.postMessage({t:Date.now()})}catch{}
  return true;
}
function lfAct(id,fn,msg){
  const done=lfUpdate(items=>{
    const x=items.find(i=>i.id===id);
    if(!x){toast("This listing was removed in another window.");return false}
    if(fn(x,items)===false)return false;
    lfRecalc(x);x.updatedAt=new Date().toISOString();
  });
  if(done&&msg)toast(msg);
  lfRerender();
  return done;
}

/* ---------- smart matching: a Lost item vs. a Found item ---------- */
const LF_STOP=new Set("the and for with near has have this that item lost found small big old new from was".split(" "));
const lfTokens=s=>[...new Set(String(s||"").toLowerCase().split(/[^a-z0-9]+/).filter(w=>w.length>2&&!LF_STOP.has(w)))];
function lfMatches(item){
  if(!LF_ACTIVE.includes(item.status))return[];
  const words=new Set(lfTokens(item.title+" "+item.description)),places=new Set(lfTokens(item.location));
  return data.lostFound
    .filter(o=>o.id!==item.id&&o.kind!==item.kind&&LF_ACTIVE.includes(o.status))
    .map(o=>{let score=o.category===item.category?2:0;lfTokens(o.title+" "+o.description).forEach(w=>{if(words.has(w))score+=2});lfTokens(o.location).forEach(w=>{if(places.has(w))score+=1});return{o,score}})
    .filter(m=>m.score>=4).sort((a,b)=>b.score-a.score).slice(0,3).map(m=>m.o);
}

/* ---------- list, filters, stats ---------- */
function lfVisible(){
  const q=lostState.q.toLowerCase().trim();
  let items=data.lostFound.map((x,i)=>({x,i,t:Date.parse(x.createdAt)||0})).filter(({x})=>
    (role==="warden"||x.status!=="Archived")&&
    (lostState.kind==="All"||x.kind===lostState.kind)&&
    (lostState.category==="All"||x.category===lostState.category)&&
    (lostState.status==="All"||x.status===lostState.status)&&
    (!q||[x.id,x.title,x.category,x.location,x.description,x.kind,x.student].some(v=>String(v||"").toLowerCase().includes(q)))&&
    (!lostState.mine||(role==="warden"?x.status==="Claim pending":(x.student===userName||x.claims.some(c=>c.by===userName)))));
  const dir=lostState.sort==="old"?1:-1;
  items.sort((a,b)=>dir*((a.t-b.t)||(a.i-b.i)));
  return items.map(o=>o.x);
}
function lfStatsHtml(){
  const L=data.lostFound.filter(x=>x.status!=="Archived");
  const claims=L.flatMap(x=>x.claims);
  const tiles=[
    ["Active listings",L.filter(x=>LF_ACTIVE.includes(x.status)).length,"open"],
    role==="warden"?["Claims to review",claims.filter(c=>c.status==="Pending").length,"review"]:["My pending claims",claims.filter(c=>c.by===userName&&c.status==="Pending").length,"review"],
    ["Items returned",L.filter(x=>x.status==="Returned").length,"done"],
    role==="warden"?["Total listings",L.length,"all"]:["My listings",L.filter(x=>x.student===userName).length,"all"]];
  return tiles.map(t=>`<div class="lf-stat ${t[2]}"><b>${t[1]}</b><span>${t[0]}</span></div>`).join("");
}
function lfNavCount(){
  const el=$("#lostFoundNavCount");if(!el)return;
  const L=data.lostFound.filter(x=>x.status!=="Archived");
  el.textContent=L.filter(x=>LF_ACTIVE.includes(x.status)).length;
  const urgent=role==="warden"?L.some(x=>x.status==="Claim pending"):L.some(x=>x.claims.some(c=>c.by===userName&&c.status==="Approved"&&x.status==="Returned"&&x.updatedAt&&Date.now()-Date.parse(x.updatedAt)<864e5));
  el.classList.toggle("lf-alert",urgent);
}
function lfBadgeText(){return`● Live · synced ${lfLastSync.toLocaleTimeString("en-IN",{hour:"numeric",minute:"2-digit"})}`}

function lostFoundView(){
  const active=data.lostFound.filter(x=>LF_ACTIVE.includes(x.status)&&(role==="warden"||x.status!=="Archived")).length;
  const sel=(id,cur,opts)=>`<select id="${id}" aria-label="${id}">${opts.map(o=>`<option value="${esc(o[0])}" ${cur===o[0]?"selected":""}>${esc(o[1])}</option>`).join("")}</select>`;
  return `${heading("Lost & Found","Report an item, search listings, claim what's yours — every change shows up instantly in every open window.",`<span class="lf-sync" id="lfSyncBadge" title="Student and warden windows update each other automatically">${lfBadgeText()}</span><span class="pill" id="lfCount">${active} active listings</span>`)}
  <section class="lostfound-hero"><div><span class="eyebrow">CAMPUS RECOVERY NETWORK / 01</span><h2>Lost something?<br><span>Let’s bring it back.</span></h2><p>Every found item is a chance to make someone's day.</p><div class="lostfound-actions"><button class="btn btn-primary" data-lf="form" data-kind="Lost">＋ Report lost item</button><button class="btn btn-ghost" data-lf="form" data-kind="Found">＋ I found something</button></div></div><div class="lostfound-orb"><div class="orb-ring ring-one"></div><div class="orb-ring ring-two"></div><div class="orb-core">⌕</div><span class="orb-tag tag-one">FOUND / 02</span><span class="orb-tag tag-two">MATCHING IN PROGRESS</span></div></section>
  <div class="lf-stats" id="lfStats">${lfStatsHtml()}</div>
  <div class="lostfound-tools lf-tools"><label class="lost-search">⌕ <input id="lostSearch" value="${esc(lostState.q)}" autocomplete="off" placeholder="Search item, place, ID or category…" aria-label="Search lost and found items"></label><div class="lost-filters">${["All","Lost","Found"].map(k=>`<button class="lost-filter ${lostState.kind===k?"active":""}" data-lf="kind" data-v="${k}">${k==="All"?"All items":k}</button>`).join("")}</div></div>
  <div class="lf-selects">${sel("lfStatus",lostState.status,[["All","Any status"],["Open","Open"],["Claim pending","Claim pending"],["Returned","Returned"],...(role==="warden"?[["Archived","Archived"]]:[])])}${sel("lfCategory",lostState.category,[["All","All categories"],...LF_CATEGORIES.map(c=>[c,c])])}${sel("lfSort",lostState.sort,[["new","Newest first"],["old","Oldest first"]])}<label class="lf-toggle"><input type="checkbox" id="lfMine" ${lostState.mine?"checked":""}> ${role==="warden"?"Needs my review":"My activity only"}</label></div>
  <div class="lostfound-grid" id="lostFoundGrid">${lostFoundCards(lfVisible())}</div>
  <section class="lostfound-tip"><span>✦</span><div><b>Keep it safe, keep it kind.</b><p>Meet in a public hostel area and verify ownership before handing over valuables. Claims are reviewed by the warden. Demo listings are saved only in this browser.</p></div></section>`;
}
function lfRefreshGrid(){
  const g=$("#lostFoundGrid");if(!g)return;
  g.innerHTML=lostFoundCards(lfVisible());
  const s=$("#lfStats");if(s)s.innerHTML=lfStatsHtml();
  const c=$("#lfCount");if(c)c.textContent=data.lostFound.filter(x=>LF_ACTIVE.includes(x.status)&&(role==="warden"||x.status!=="Archived")).length+" active listings";
  lfNavCount();
}

function lostFoundCards(items){
  if(!items.length){
    const filtered=lostState.q||lostState.kind!=="All"||lostState.status!=="All"||lostState.category!=="All"||lostState.mine;
    return `<div class="empty-state lost-empty"><span>⌕</span><b>No matching items</b><p>${filtered?"Nothing fits these filters.":"Be the first to report an item."}</p>${filtered?`<button class="btn btn-outline btn-sm" data-lf="clear">Clear filters</button>`:""}</div>`;
  }
  return items.map(x=>{
    const k=x.kind.toLowerCase(),photo=lfSafePhoto(x.photo);
    const pending=x.claims.filter(c=>c.status==="Pending").length;
    const mine=x.claims.filter(c=>c.by===userName);
    const myLast=mine[mine.length-1];
    const matches=lfMatches(x).length;
    const canClaim=role!=="warden"&&x.student!==userName&&LF_ACTIVE.includes(x.status)&&!mine.some(c=>c.status==="Pending");
    const media=photo?`<div class="lost-photo"><img src="${photo}" alt="${esc(x.title)}" loading="lazy"></div>`:`<div class="lost-item-icon">${LF_ICONS[x.category]||"✦"}</div>`;
    return `<article class="lost-item-card ${k}">
      <div class="lost-card-top"><span class="lost-kind ${k}">${x.kind==="Lost"?"◉ LOST ITEM":"✦ FOUND ITEM"}</span><span class="lost-id">${esc(x.id)}</span></div>
      ${media}<h3>${esc(x.title)}</h3>
      <div class="lf-chips"><span class="lost-category">${esc(x.category)}</span>${lfStatusPill(x.status)}${matches?`<span class="lf-chip match">↔ ${matches} possible match${matches>1?"es":""}</span>`:""}${role==="warden"&&pending?`<span class="lf-chip warn">${pending} claim${pending>1?"s":""} to review</span>`:""}${myLast?`<span class="lf-chip ${statusClass(myLast.status)}">Your claim: ${esc(myLast.status)}</span>`:""}</div>
      <p class="lost-description">${esc(x.description)}</p>
      <div class="lost-meta"><span>⌖ ${esc(x.location)}</span><span>◷ ${esc(lfDateLabel(x))}</span></div>
      <div class="lost-card-bottom"><span class="lost-owner">Reported by ${esc(x.student)}</span><span class="lf-card-actions"><button class="btn btn-sm btn-outline" data-lf="open" data-id="${esc(x.id)}">${role==="warden"&&pending?"Review →":"Details"}</button>${canClaim?`<button class="btn btn-sm ${x.kind==="Lost"?"btn-primary":"btn-dark"}" data-lf="claim" data-id="${esc(x.id)}">${x.kind==="Lost"?"I found this →":"Claim item →"}</button>`:""}</span></div>
      ${role==="warden"?`<button class="lost-archive" data-lf="archive" data-id="${esc(x.id)}">${x.status==="Archived"?"Restore listing":"Archive listing"}</button>`:""}
    </article>`;
  }).join("");
}

/* ---------- detail modal (its body refreshes live; the claim form does not) ---------- */
function lfLiveHtml(x){
  const warden=role==="warden",isOwner=x.student===userName,k=x.kind.toLowerCase();
  const mine=x.claims.filter(c=>c.by===userName),myPending=mine.some(c=>c.status==="Pending");
  const active=LF_ACTIVE.includes(x.status);
  const photo=lfSafePhoto(x.photo),matches=lfMatches(x);
  const approved=x.claims.find(c=>c.status==="Approved");
  const visible=warden?x.claims:mine;
  const claimLabel=x.kind==="Lost"?"I found this →":"Claim this item →";
  return `<span class="eyebrow">LOST & FOUND / ITEM ${esc(x.id)}</span>
  <h2 class="lf-title">${esc(x.title)}</h2>
  <div class="lf-chips"><span class="lost-kind ${k}">${x.kind==="Lost"?"◉ LOST ITEM":"✦ FOUND ITEM"}</span>${lfStatusPill(x.status)}<span class="lost-category">${esc(x.category)}</span></div>
  ${photo?`<img class="lf-detail-photo" src="${photo}" alt="${esc(x.title)}">`:""}
  <p class="lf-desc">${esc(x.description)}</p>
  <dl class="lf-facts"><div><dt>${x.kind==="Lost"?"Lost at":"Found at"}</dt><dd>${esc(x.location)}</dd></div><div><dt>Date</dt><dd>${esc(lfDateLabel(x))}</dd></div><div><dt>Reported by</dt><dd>${esc(x.student)}</dd></div><div><dt>Safe contact route</dt><dd>${esc(x.contact||"Hostel reception")}</dd></div></dl>
  ${approved&&(warden||approved.by===userName||isOwner)?`<div class="ai-insight lf-success"><span class="ai-star">✓</span><div><b>${x.kind==="Lost"?"Match confirmed":"Claim approved"} — returned to ${esc(approved.by)}</b><p>Collect or hand over via ${esc(x.contact||"Hostel reception")} and quote item ID ${esc(x.id)}. Carry your student ID.</p></div></div>`:""}
  ${matches.length?`<div class="lf-section"><h4>✦ Possible matches</h4>${matches.map(m=>`<button class="lf-match" data-lf="open" data-id="${esc(m.id)}"><span class="lost-kind ${m.kind.toLowerCase()}">${esc(m.kind)}</span><b>${esc(m.title)}</b><small>${esc(m.location)}</small><i>→</i></button>`).join("")}</div>`:""}
  ${visible.length?`<div class="lf-section"><h4>${warden?"Claims":"Your claim"}</h4>${visible.map(c=>`<div class="lf-claim ${statusClass(c.status)}"><div class="lf-claim-head"><b>${esc(c.by)}</b><small>${lfWhen(c.at)}</small><span class="lf-chip ${statusClass(c.status)}">${esc(c.status)}</span></div><p>${esc(c.note)}</p>${warden&&c.status==="Pending"?`<div class="lf-claim-actions"><button class="btn btn-sm btn-primary" data-lf="approve" data-id="${esc(x.id)}" data-claim="${esc(c.id)}">Approve &amp; mark returned</button><button class="btn btn-sm btn-outline" data-lf="reject" data-id="${esc(x.id)}" data-claim="${esc(c.id)}">Reject</button></div>`:""}${!warden&&c.status==="Pending"?`<div class="lf-claim-actions"><button class="btn btn-sm btn-outline" data-lf="withdraw" data-id="${esc(x.id)}" data-claim="${esc(c.id)}">Withdraw claim</button></div>`:""}</div>`).join("")}</div>`:""}
  ${!warden&&isOwner&&x.claims.some(c=>c.status==="Pending")?`<p class="lf-note">${x.claims.filter(c=>c.status==="Pending").length} claim(s) waiting for the warden to review.</p>`:""}
  ${x.history.length?`<div class="lf-section"><h4>Activity</h4><ol class="lf-timeline">${x.history.slice(-6).reverse().map(h=>`<li><span>${esc(h.text)}</span><small>${lfWhen(h.at)}</small></li>`).join("")}</ol></div>`:""}
  <div class="form-actions lf-actions">
    ${!warden&&!isOwner&&active&&!myPending?`<button class="btn btn-primary btn-sm" data-lf="claim" data-id="${esc(x.id)}">${claimLabel}</button>`:""}
    ${(isOwner||warden)&&active?`<button class="btn btn-ghost btn-sm" data-lf="returned" data-id="${esc(x.id)}">Mark as returned</button>`:""}
    ${(isOwner||warden)&&x.status!=="Returned"?`<button class="btn btn-ghost btn-sm" data-lf="edit" data-id="${esc(x.id)}">Edit</button>`:""}
    ${warden&&x.status==="Returned"?`<button class="btn btn-ghost btn-sm" data-lf="reopen" data-id="${esc(x.id)}">Reopen</button>`:""}
    ${warden?`<button class="btn btn-ghost btn-sm" data-lf="archive" data-id="${esc(x.id)}">${x.status==="Archived"?"Restore":"Archive"}</button>`:""}
    ${(isOwner||warden)?`<button class="btn btn-sm lf-danger" data-lf="delete" data-id="${esc(x.id)}">Delete</button>`:""}
  </div>`;
}
function lfOpenDetail(id){
  const x=data.lostFound.find(i=>i.id===id);
  if(!x){toast("That listing no longer exists.");return}
  openGeneric(`<button class="modal-close" data-close-modal aria-label="Close">×</button><div id="lfLive">${lfLiveHtml(x)}</div><div id="lfClaimBox"></div>`);
  $("#genericModalBody").classList.add("lf-modal");
  lostState.openId=id;
}
function lfRefreshModal(){
  if(!lostState.openId||$("#genericModal").classList.contains("hidden"))return;
  const live=$("#lfLive");if(!live)return;
  const x=data.lostFound.find(i=>i.id===lostState.openId);
  if(!x||(x.status==="Archived"&&role!=="warden")){closeModal();toast("This listing was removed or archived in another window.");return}
  live.innerHTML=lfLiveHtml(x);
}
function lfRerender(){
  if(currentView==="lostfound"){lfRefreshGrid()}
  else{
    const a=document.activeElement,typing=a&&/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName);
    if($("#genericModal").classList.contains("hidden")&&!typing)renderView();else lfNavCount();
  }
  lfRefreshModal();
}

/* ---------- claim form ---------- */
function lfShowClaimForm(id){
  const x=data.lostFound.find(i=>i.id===id),box=$("#lfClaimBox");
  if(!x||!box)return;
  const lost=x.kind==="Lost";
  box.innerHTML=`<form id="lfClaimForm" class="lf-claim-form"><h3>${lost?"Tell the warden how you found it":"Prove it’s yours"}</h3><div class="field"><label for="lfClaimNote">${lost?"Where did you find it, and in what condition?":"Describe a detail only the owner would know"}</label><textarea id="lfClaimNote" required minlength="10" maxlength="400" placeholder="${lost?"e.g. Near the Block A stairs, handed to security desk":"e.g. Scratch on the back, lock-screen photo, sticker location…"}"></textarea><small>Only the warden can read this. Contact details are never shared automatically.</small></div><div class="form-actions"><button type="button" class="btn btn-outline btn-sm" data-lf="claim-cancel">Cancel</button><button class="btn btn-primary btn-sm">Submit claim →</button></div></form>`;
  box.scrollIntoView({behavior:"smooth",block:"nearest"});
  $("#lfClaimNote").focus();
  $("#lfClaimForm").addEventListener("submit",e=>{
    e.preventDefault();
    const note=$("#lfClaimNote").value.trim();
    if(note.length<10){toast("Please add a little more detail.");return}
    const ok=lfAct(id,t=>{
      if(!LF_ACTIVE.includes(t.status)){toast(`This item is already ${t.status.toLowerCase()}.`);return false}
      if(t.student===userName||role==="warden"){toast("You can’t claim your own listing.");return false}
      if(t.claims.some(c=>c.by===userName&&c.status==="Pending")){toast("You already have a pending claim on this item.");return false}
      t.claims.push({id:"CL"+Math.random().toString(36).slice(2,7).toUpperCase(),by:userName,note,at:new Date().toISOString(),status:"Pending"});
      lfLog(t,`${userName} ${t.kind==="Lost"?"reported finding this item":"claimed this item"}`);
    },"Claim sent — the warden will review it.");
    if(ok){const b=$("#lfClaimBox");if(b)b.innerHTML=""}
  });
}

/* ---------- create / edit form ---------- */
function lfCompress(file){
  return new Promise((resolve,reject)=>{
    if(!/^image\//.test(file.type))return reject(new Error("Please choose an image file."));
    const r=new FileReader();
    r.onerror=()=>reject(new Error("Could not read that file."));
    r.onload=()=>{
      const img=new Image();
      img.onerror=()=>reject(new Error("That image could not be opened."));
      img.onload=()=>{
        let max=520,q=.72,url="";
        for(let i=0;i<4;i++){
          const s=Math.min(1,max/Math.max(img.width,img.height)),c=document.createElement("canvas");
          c.width=Math.max(1,Math.round(img.width*s));c.height=Math.max(1,Math.round(img.height*s));
          const g=c.getContext("2d");g.fillStyle="#fff";g.fillRect(0,0,c.width,c.height);g.drawImage(img,0,0,c.width,c.height);
          url=c.toDataURL("image/jpeg",q);
          if(url.length<110000)break;
          max-=90;q-=.1;
        }
        resolve(url);
      };
      img.src=r.result;
    };
    r.readAsDataURL(file);
  });
}
function lfForm(kind,editId){
  const x=editId?data.lostFound.find(i=>i.id===editId):null;
  if(editId&&!x){toast("That listing no longer exists.");return}
  kind=x?x.kind:kind;
  let photo=x?lfSafePhoto(x.photo):"";
  const v=(f,d="")=>esc(x?x[f]||d:d);
  const iso=isoToday();
  openGeneric(`<button class="modal-close" data-close-modal aria-label="Close">×</button><span class="eyebrow">CAMPUS RECOVERY NETWORK</span><h2>${x?"Edit your <span>listing.</span>":kind==="Lost"?"Report a <span>lost item.</span>":"Report a <span>found item.</span>"}</h2><p>Share clear details so the right person can recognize the item.</p>
  <form id="lostFoundForm">
    <div class="field"><label for="lfTitle">Item name</label><input id="lfTitle" required maxlength="90" value="${v("title")}" placeholder="e.g. Black umbrella" /></div>
    <div class="form-grid"><div class="field"><label for="lfCategoryIn">Category</label><select id="lfCategoryIn">${LF_CATEGORIES.map(c=>`<option ${x&&x.category===c?"selected":""}>${c}</option>`).join("")}</select></div><div class="field"><label for="lfLocation">Where?</label><input id="lfLocation" required maxlength="100" list="lfPlaces" value="${v("location")}" placeholder="e.g. Block B lobby" /><datalist id="lfPlaces">${LF_PLACES.map(p=>`<option value="${p}">`).join("")}</datalist></div></div>
    <div class="form-grid"><div class="field"><label for="lfDate">${kind==="Lost"?"Date lost":"Date found"}</label><input id="lfDate" type="date" max="${iso}" required value="${esc(x&&x.eventDate?x.eventDate:iso)}" /></div><div class="field"><label for="lfContact">Safe contact route</label><select id="lfContact">${LF_ROUTES.map(r=>`<option ${x&&x.contact===r?"selected":""}>${r}</option>`).join("")}</select></div></div>
    <div class="field"><label for="lfDescription">Description</label><textarea id="lfDescription" required maxlength="500" placeholder="Color, brand, identifying details…">${v("description")}</textarea></div>
    <div class="field"><label for="lfPhoto">Photo <small>(optional)</small></label><div class="lf-photo-field"><div class="lf-photo-preview" id="lfPhotoPreview"></div><div><input id="lfPhoto" type="file" accept="image/*"><button type="button" class="lost-archive" id="lfPhotoClear">Remove photo</button></div></div><small>Avoid photos showing personal documents or faces. For this demo, do not enter personal phone numbers.</small></div>
    <div class="form-actions"><button type="button" class="btn btn-outline btn-sm" data-close-modal>Cancel</button><button class="btn btn-primary btn-sm">${x?"Save changes →":"Publish listing →"}</button></div>
  </form>`);
  $("#genericModalBody").classList.remove("lf-modal");
  lostState.openId=null;
  const paint=()=>{$("#lfPhotoPreview").innerHTML=photo?`<img src="${photo}" alt="Preview">`:"<span>No photo</span>";$("#lfPhotoClear").classList.toggle("hidden",!photo)};
  paint();
  $("#lfPhoto").addEventListener("change",async e=>{const f=e.target.files[0];if(!f)return;try{photo=await lfCompress(f);paint()}catch(err){toast(err.message);e.target.value=""}});
  $("#lfPhotoClear").addEventListener("click",()=>{photo="";$("#lfPhoto").value="";paint()});
  $("#lostFoundForm").addEventListener("submit",e=>{
    e.preventDefault();
    const f={title:$("#lfTitle").value.trim(),category:$("#lfCategoryIn").value,location:$("#lfLocation").value.trim(),eventDate:$("#lfDate").value,description:$("#lfDescription").value.trim(),contact:$("#lfContact").value,photo};
    if(!f.title||!f.location||!f.description){toast("Please fill in all required fields.");return}
    const now=new Date().toISOString();
    const ok=lfUpdate(items=>{
      if(x){
        const t=items.find(i=>i.id===x.id);
        if(!t){toast("This listing was removed in another window.");return false}
        if(t.student!==userName&&role!=="warden"){toast("Only the person who posted this can edit it.");return false}
        if(t.status==="Returned"){toast("This item was already returned, so it can’t be edited.");return false}
        Object.assign(t,f);lfLog(t,"Listing edited");t.updatedAt=now;
      }else{
        const n=lfNorm({id:lfNewId(items),kind,...f,student:userName,date:fmtDate(),createdAt:now,updatedAt:now,status:"Open"});
        lfLog(n,`${userName} reported this ${kind.toLowerCase()} item`);
        items.push(n);
      }
    });
    if(ok){closeModal();currentView="lostfound";renderView();toast(x?"Listing updated.":`${kind} item listing published.`)}
  });
}

/* ---------- one delegated click handler for everything above ---------- */
document.addEventListener("click",e=>{
  const b=e.target.closest("[data-lf]");if(!b)return;
  const a=b.dataset.lf,id=b.dataset.id,cid=b.dataset.claim;
  const warden=role==="warden";
  switch(a){
    case"form":lfForm(b.dataset.kind);break;
    case"edit":lfForm(null,id);break;
    case"open":lfOpenDetail(id);break;
    case"claim":if(!$("#lfClaimBox")||lostState.openId!==id)lfOpenDetail(id);lfShowClaimForm(id);break;
    case"claim-cancel":{const bx=$("#lfClaimBox");if(bx)bx.innerHTML="";break}
    case"kind":lostState.kind=b.dataset.v;lfSaveUi();$$('[data-lf="kind"]').forEach(x=>x.classList.toggle("active",x===b));lfRefreshGrid();break;
    case"clear":Object.assign(lostState,{q:"",kind:"All",status:"All",category:"All",mine:false});lfSaveUi();renderView();break;
    case"approve":
      if(!warden)break;
      lfAct(id,x=>{
        const c=x.claims.find(k=>k.id===cid);
        if(!c||c.status!=="Pending"){toast("That claim was already handled.");return false}
        if(!LF_ACTIVE.includes(x.status)){toast(`This item is already ${x.status.toLowerCase()}.`);return false}
        c.status="Approved";
        x.claims.forEach(o=>{if(o!==c&&o.status==="Pending")o.status="Closed"});
        x.status="Returned";x.returnedTo=c.by;
        lfLog(x,`Warden approved ${c.by}’s claim — item returned`);
      },"Claim approved — item marked as returned.");break;
    case"reject":
      if(!warden)break;
      lfAct(id,x=>{
        const c=x.claims.find(k=>k.id===cid);
        if(!c||c.status!=="Pending"){toast("That claim was already handled.");return false}
        c.status="Rejected";lfLog(x,`Warden did not approve ${c.by}’s claim`);
      },"Claim rejected.");break;
    case"withdraw":
      lfAct(id,x=>{
        const c=x.claims.find(k=>k.id===cid);
        if(!c||c.by!==userName||c.status!=="Pending"){toast("That claim can’t be withdrawn any more.");return false}
        c.status="Withdrawn";lfLog(x,`${userName} withdrew their claim`);
      },"Claim withdrawn.");break;
    case"returned":
      lfAct(id,x=>{
        if(x.student!==userName&&!warden)return false;
        if(!LF_ACTIVE.includes(x.status)){toast(`This item is already ${x.status.toLowerCase()}.`);return false}
        x.claims.forEach(c=>{if(c.status==="Pending")c.status="Closed"});
        x.status="Returned";lfLog(x,`${warden?"Warden":userName} marked this item as returned`);
      },"Marked as returned.");break;
    case"reopen":
      if(!warden)break;
      lfAct(id,x=>{x.claims.forEach(c=>{if(c.status==="Approved")c.status="Closed"});x.status="Open";delete x.returnedTo;lfLog(x,"Warden reopened this listing")},"Listing reopened.");break;
    case"archive":
      if(!warden)break;
      lfAct(id,x=>{
        if(x.status==="Archived"){x.status=x.archivedFrom||"Open";delete x.archivedFrom;lfLog(x,"Listing restored")}
        else{x.archivedFrom=x.status;x.status="Archived";lfLog(x,"Listing archived")}
      },"Listing updated.");break;
    case"delete":{
      if(!confirm("Delete this listing permanently? This can’t be undone."))break;
      const done=lfUpdate(items=>{
        const i=items.findIndex(x=>x.id===id);
        if(i<0){toast("This listing was already removed.");return false}
        if(items[i].student!==userName&&!warden)return false;
        items.splice(i,1);
      });
      if(done){closeModal();toast("Listing deleted.")}
      lfRerender();break;
    }
  }
});
document.addEventListener("input",e=>{if(e.target.id==="lostSearch"){lostState.q=e.target.value;lfSaveUi();lfRefreshGrid()}});
document.addEventListener("change",e=>{
  const t=e.target,map={lfStatus:"status",lfCategory:"category",lfSort:"sort"};
  if(map[t.id]){lostState[map[t.id]]=t.value;lfSaveUi();lfRefreshGrid()}
  else if(t.id==="lfMine"){lostState.mine=t.checked;lfSaveUi();lfRefreshGrid()}
});

/* ---------- live sync between windows ---------- */
function lfSnap(list){const m={};(list||[]).forEach(x=>{const c={};(x.claims||[]).forEach(k=>{c[k.id]={s:k.status,by:k.by}});m[x.id]={s:x.status,t:x.title,o:x.student,c}});return m}
function lfDiffToast(before,after){
  let msg="";
  for(const id in after){
    const n=after[id],o=before[id];
    if(!o){if(n.o!==userName&&n.s!=="Archived"&&!msg)msg=`New listing: ${n.t}`;continue}
    for(const cid in n.c){
      const nc=n.c[cid],oc=o.c[cid];
      if(role==="warden"&&nc.s==="Pending"&&!oc)return`New claim to review on “${n.t}”`;
      if(nc.by===userName&&oc&&oc.s==="Pending"&&nc.s==="Approved")return`Your claim on “${n.t}” was approved ✓`;
      if(nc.by===userName&&oc&&oc.s==="Pending"&&nc.s==="Rejected")return`Your claim on “${n.t}” was not approved`;
    }
    if(n.o===userName&&o.s!==n.s&&n.s==="Returned"&&!msg)msg=`“${n.t}” was marked as returned`;
  }
  return msg;
}
function lfSync(){
  const raw=localStorage.getItem(STORAGE_KEY);
  if(raw===lastRaw)return;
  lastRaw=raw;
  const before=lfSnap(data.lostFound);
  data=lfCurrentData();
  lfLastSync=new Date();
  const badge=$("#lfSyncBadge");if(badge){badge.textContent=lfBadgeText();badge.classList.remove("flash");void badge.offsetWidth;badge.classList.add("flash")}
  const msg=lfDiffToast(before,lfSnap(data.lostFound));
  lfRerender();
  if(msg)toast(msg);
}
function studentsView(){return `${heading("Student directory","A simple demo roster for the warden workspace.")}<section class="panel"><div class="panel-header"><div><h3>Registered students</h3><p>${data.students.length} sample student profiles</p></div><button class="btn btn-primary btn-sm" data-action="add-student">＋ Add student</button></div><div class="data-table-wrap"><table class="data-table"><thead><tr><th>STUDENT</th><th>ROOM</th><th>OPEN COMPLAINTS</th><th>LEAVE REQUESTS</th></tr></thead><tbody>${data.students.map((s,i)=>`<tr><td><b>${esc(s)}</b><span class="table-sub">Student profile · Demo</span></td><td>${["Room 203","Block B · 104","Room 118","Block A · 205","Room 307","Block C · 110"][i%6]}</td><td>${data.complaints.filter(c=>c.student===s&&c.status!=="Resolved").length}</td><td>${data.leaves.filter(l=>l.student===s).length}</td></tr>`).join("")}</tbody></table></div></section>`}
function renderView(){if(!$("#viewRoot"))return;const views={dashboard:dashboardView,complaints:complaintsView,mess:messView,leave:leaveView,announcements:announcementsView,lostfound:lostFoundView,booking:bookingView,students:studentsView};$("#viewRoot").innerHTML=(views[currentView]||dashboardView)();$("#complaintNavCount").textContent=data.complaints.filter(c=>c.status!=="Resolved").length;const lfCount=$("#lostFoundNavCount");lfNavCount();const bkCount=$("#bookingNavCount");if(bkCount)bkCount.textContent=data.bookings.filter(b=>b.status==="Confirmed"&&b.date>=isoToday()&&(role==="warden"||b.student===userName)).length;bindViewEvents()}
function bindViewEvents(){
 $$("[data-view]",$("#viewRoot")).forEach(el=>el.addEventListener("click",()=>goView(el.dataset.view)));
 $$("[data-category]").forEach(b=>b.addEventListener("click",()=>{$$("#categoryChips .category-chip").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");$("#manualCategory").value=b.dataset.category;if(lastAnalysis)showAnalysis(lastAnalysis)}));
 $("#analyzeBtn")?.addEventListener("click",()=>{const text=$("#complaintTitle").value+" "+$("#complaintDescription").value;if(!text.trim())return toast("Add a title or description first.");lastAnalysis=analyzeComplaint(text);showAnalysis(lastAnalysis)});
 $("#complaintDescription")?.addEventListener("input",()=>{if(lastAnalysis){lastAnalysis=null;$("#aiResult").classList.remove("visible")}});
 $("#complaintForm")?.addEventListener("submit",e=>{e.preventDefault();const title=$("#complaintTitle").value.trim(),desc=$("#complaintDescription").value.trim();const ai=analyzeComplaint(title+" "+desc);const category=$("#manualCategory").value||ai.category;data.complaints.push({id:safeId(),title,description:desc,category,priority:ai.priority,status:"Pending",room:"Not specified",created:fmtDate(),student:userName});save();toast("Complaint submitted — "+category+" category suggested.");renderView()});
 $("#refreshComplaints")?.addEventListener("click",()=>{renderView();toast("Complaint list refreshed.")});
 $$("[data-complaint-status]").forEach(sel=>sel.addEventListener("change",()=>{const c=data.complaints.find(x=>x.id===sel.dataset.complaintStatus);if(c){c.status=sel.value;save();toast("Complaint status updated.");renderView()}}));
 $("#leaveForm")?.addEventListener("submit",e=>{e.preventDefault();const from=$("#leaveFrom").value,to=$("#leaveTo").value;if(to<from)return toast("End date must be on or after start date.");data.leaves.push({id:safeId(),type:$("#leaveType").value,from,to,reason:$("#leaveReason").value.trim(),status:"Pending",student:userName,created:fmtDate()});save();toast("Leave request sent to the warden.");renderView()});
 $$("[data-leave-action]").forEach(b=>b.addEventListener("click",()=>{const l=data.leaves.find(x=>x.id===b.dataset.id);if(l){l.status=b.dataset.leaveAction;save();toast("Leave status updated.");renderView()}}));
 $$("[data-day]").forEach(b=>b.addEventListener("click",()=>{selectedDay=b.dataset.day;renderView()}));
 $$("[data-rating]").forEach(b=>b.addEventListener("click",()=>{selectedRating=Number(b.dataset.rating);$$("[data-rating]").forEach(x=>x.classList.toggle("active",Number(x.dataset.rating)<=selectedRating));$("#ratingHelp").textContent=`${selectedRating} out of 5 stars`}));
 $("#feedbackForm")?.addEventListener("submit",e=>{e.preventDefault();if(!selectedRating)return toast("Choose a star rating first.");data.feedback.push({meal:$("#feedbackMeal").value,rating:selectedRating,text:$("#feedbackText").value.trim(),student:userName,date:fmtDate()});save();selectedRating=0;toast("Thanks! Your meal feedback was saved.");renderView()});

 // Facility booking interactions
 $("#bkFacility")?.addEventListener("change",e=>{bookingDraft={...bookingDraft,facility:e.target.value,slot:""};renderView()});
 $("#bkDate")?.addEventListener("change",e=>{if(!e.target.value)return;bookingDraft={...bookingDraft,date:e.target.value,slot:""};renderView()});
 $$("[data-slot]").forEach(b=>b.addEventListener("click",()=>{bookingDraft.slot=b.dataset.slot;renderView()}));
 $("#confirmBooking")?.addEventListener("click",()=>{
  const d=bookingDraft,active=b=>b.status==="Confirmed"&&b.facility===d.facility&&b.date===d.date;
  if(!d.slot)return toast("Pick a time slot first.");
  if(d.date<isoToday())return toast("Choose today or a future date.");
  if(data.bookings.some(b=>active(b)&&b.slot===d.slot))return toast("That slot was just taken — pick another.");
  if(data.bookings.some(b=>active(b)&&b.student===userName))return toast(`You already have a ${d.facility} booking that day.`);
  data.bookings.push({id:safeId().replace("HM","BK"),facility:d.facility,date:d.date,slot:d.slot,student:userName,status:"Confirmed",created:fmtDate()});
  save();toast(`${d.facility} booked for ${d.slot}.`);bookingDraft.slot="";renderView();
 });
 $$("[data-cancel-booking]").forEach(b=>b.addEventListener("click",()=>{const bk=data.bookings.find(x=>x.id===b.dataset.cancelBooking);if(bk&&(role==="warden"||bk.student===userName)){bk.status="Cancelled";save();toast("Booking cancelled — the slot is free again.");renderView()}}));

// Lost & Found interactions are handled by one delegated listener (see the Lost & Found module)

 $$("[data-action='new-announcement']").forEach(b=>b.addEventListener("click",newAnnouncementModal));
 $$("[data-action='add-student']").forEach(b=>b.addEventListener("click",addStudentModal));
 $$("[data-delete-announcement]").forEach(b=>b.addEventListener("click",()=>{if(confirm("Delete this announcement?")){data.announcements=data.announcements.filter(a=>a.id!==b.dataset.deleteAnnouncement);save();renderView();toast("Announcement deleted.")}}));
}
const FACILITIES={"Laundry":"🧺","Study room":"📚","Common room":"🎮","Gym":"🏋️"};
const SLOTS=["6:00 AM","8:00 AM","10:00 AM","12:00 PM","4:00 PM","6:00 PM","8:00 PM"];
let bookingDraft={facility:"Laundry",date:isoToday(),slot:""};
function bookingView(){
 const d=bookingDraft;
 const taken=new Set(data.bookings.filter(b=>b.status==="Confirmed"&&b.facility===d.facility&&b.date===d.date).map(b=>b.slot));
 const mine=data.bookings.filter(b=>role==="warden"||b.student===userName);
 const activeCount=data.bookings.filter(b=>b.status==="Confirmed"&&b.date>=isoToday()).length;
 const rows=[...mine].sort((a,b)=>(b.date+b.id).localeCompare(a.date+a.id)).map(b=>`<tr><td><b>${FACILITIES[b.facility]||"✦"} ${esc(b.facility)}</b><span class="table-sub">${esc(b.id)}${role==="warden"?" · "+esc(b.student):""}</span></td><td>${esc(b.date)}</td><td>${esc(b.slot)}</td><td>${statusPill(b.status)}</td><td>${b.status==="Confirmed"?`<button class="tiny-btn reject" data-cancel-booking="${esc(b.id)}">Cancel</button>`:""}</td></tr>`).join("");
 return `${heading("Facility booking",role==="warden"?"See every facility booking and cancel one if needed.":"Reserve laundry, study rooms and more — one slot at a time, no queues.",`<span class="pill">${activeCount} upcoming</span>`)}
 ${role==="warden"?"":`<div class="dashboard-grid"><section class="form-panel"><div class="panel"><div class="panel-header"><div><h3>Book a slot</h3><p>Pick a facility, a date and a time.</p></div><span class="stat-icon blue">◷</span></div>
 <div class="form-grid"><div class="field"><label for="bkFacility">Facility</label><select id="bkFacility">${Object.keys(FACILITIES).map(f=>`<option ${f===d.facility?"selected":""}>${f}</option>`).join("")}</select></div><div class="field"><label for="bkDate">Date</label><input type="date" id="bkDate" min="${isoToday()}" value="${esc(d.date)}"/></div></div>
 <div class="field"><label>Available slots</label><div class="slot-grid">${SLOTS.map(s=>`<button type="button" class="slot-btn ${d.slot===s?"active":""}" data-slot="${s}" ${taken.has(s)?"disabled":""}>${s}</button>`).join("")}</div><small>Struck-through slots are already booked.</small></div>
 <div class="form-actions"><button class="btn btn-primary btn-sm" id="confirmBooking">Confirm booking →</button></div></div></section>
 <section class="panel"><div class="panel-header"><div><h3>Booking rules</h3><p>Keeps things fair for everyone.</p></div></div>${[["✓","One per day","One booking per facility, per student, per day."],["◷","Be on time","Slots free up if you cancel — please do it early."],["✦","Wardens can help","Wardens can see and cancel any booking."]].map(([i,t,p])=>`<div class="complaint-row" style="margin-bottom:10px"><span class="row-symbol">${i}</span><div class="row-content"><b>${t}</b><small>${p}</small></div></div>`).join("")}</section></div>`}
 <section class="panel" style="margin-top:${role==="warden"?0:16}px"><div class="panel-header"><div><h3>${role==="warden"?"All bookings":"My bookings"}</h3><p>Your reservations and their status.</p></div></div>${mine.length?`<div class="data-table-wrap"><table class="data-table"><thead><tr><th>FACILITY</th><th>DATE</th><th>SLOT</th><th>STATUS</th><th>ACTION</th></tr></thead><tbody>${rows}</tbody></table></div>`:`<div class="empty-state"><span>◷</span><b>No bookings yet</b><p>Reserve a slot above and it will show up here.</p></div>`}</section>`
}
function showAnalysis(ai){const category=$("#manualCategory").value||ai.category;$("#aiResult").innerHTML=`<div class="ai-result-header"><span>✦</span><div><b>AI analysis result</b><small>Keyword-based suggestion · Review before submitting</small></div></div><div class="ai-result-grid"><div><small>Suggested category</small><b>${iconForCategory(category)} ${category}</b></div><div><small>Suggested priority</small><b>${statusPill(ai.priority)}</b></div><div><small>Confidence estimate</small><b>${ai.confidence}% match</b></div></div><p style="font-size:10px;color:#827b9e;line-height:1.6;margin:12px 0 0">${esc(ai.suggestion)}</p>`;$("#aiResult").classList.add("visible")}
function newAnnouncementModal(){openGeneric(`<button class="modal-close" data-close-modal>×</button><span class="eyebrow">WARDEN WORKSPACE</span><h2>Post an <span>announcement.</span></h2><p>Share a useful update with hostel residents.</p><form id="announcementForm"><div class="field"><label for="announceTitle">Title</label><input id="announceTitle" required maxlength="100" placeholder="e.g. Water supply maintenance"/></div><div class="field"><label for="announceTag">Type</label><select id="announceTag"><option>General</option><option>Maintenance</option><option>Mess</option><option>Event</option></select></div><div class="field"><label for="announceBody">Message</label><textarea id="announceBody" required maxlength="700" placeholder="Write the details students need to know..."></textarea></div><div class="form-actions"><button type="button" class="btn btn-outline btn-sm" data-close-modal>Cancel</button><button class="btn btn-primary btn-sm">Publish announcement →</button></div></form>`);
 $("#announcementForm").addEventListener("submit",e=>{e.preventDefault();data.announcements.push({id:safeId(),title:$("#announceTitle").value.trim(),body:$("#announceBody").value.trim(),tag:$("#announceTag").value,date:fmtDate()});save();closeModal();renderView();toast("Announcement published.")});}
function addStudentModal(){openGeneric(`<button class="modal-close" data-close-modal>×</button><span class="eyebrow">WARDEN WORKSPACE</span><h2>Add a <span>student.</span></h2><p>Add a sample name to the local demo roster.</p><form id="studentForm"><div class="field"><label for="newStudent">Student name</label><input id="newStudent" required maxlength="60" placeholder="Enter student name"/></div><div class="form-actions"><button type="button" class="btn btn-outline btn-sm" data-close-modal>Cancel</button><button class="btn btn-primary btn-sm">Add student →</button></div></form>`);$("#studentForm").addEventListener("submit",e=>{e.preventDefault();const n=$("#newStudent").value.trim();if(data.students.some(s=>s.toLowerCase()===n.toLowerCase()))return toast("That student is already on the list.");data.students.push(n);save();closeModal();renderView();toast("Student added to demo roster.")})}
function openGeneric(html){lostState.openId=null;$("#genericModalBody").classList.remove("lf-modal");$("#genericModalBody").innerHTML=html;$("#genericModal").classList.remove("hidden");$$("[data-close-modal]").forEach(b=>b.addEventListener("click",closeModal))}
document.addEventListener("click",e=>{const v=e.target.closest("[data-view]");if(v&&v.closest("#sideNav"))goView(v.dataset.view);if(e.target.closest("[data-close-modal]"))closeModal()});
$$("[data-close-modal]").forEach(b=>b.addEventListener("click",closeModal));
$("#logoutBtn").addEventListener("click",logout);
$("#notificationBtn").addEventListener("click",()=>{const count=data.announcements.length;toast(count?`${count} hostel updates available. Open Announcements to read them.`:"You're all caught up!")});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});

// ---- Start the dashboard for this page's role ----
if (session && session.role === PAGE_ROLE) {
  // New students show up in the warden's student directory
  if (PAGE_ROLE === "student" && !data.students.some(n => n.toLowerCase() === userName.toLowerCase())) { data.students.push(userName); save(); }
  $("#todayLabel").textContent = today.toLocaleDateString("en-IN",{weekday:"short",day:"numeric",month:"short"});
  setRole(PAGE_ROLE, userName);
}
// Student and warden windows stay in sync: storage event + BroadcastChannel, with focus/poll as a safety net
window.addEventListener("storage", e => { if (e.key === STORAGE_KEY || e.key === null) lfSync(); });
if (lfChannel) lfChannel.onmessage = () => lfSync();
window.addEventListener("focus", lfSync);
document.addEventListener("visibilitychange", () => { if (!document.hidden) lfSync(); });
setInterval(() => { if (!document.hidden) lfSync(); }, 4000);
